package pageObjects;

public class SignOutPage {

}
