package pageObjects;

import org.openqa.selenium.WebDriver;

public class PageObjectManager {
	
	public SignInPage signInPageObj;
	public CreateDemandPage createDemandPageObj;
	public WebDriver driver;
	
	public PageObjectManager(WebDriver driver) {
		this.driver = driver;
	}
	
	public SignInPage getSignInPageObj() {
		
		signInPageObj = new SignInPage(driver);
		return signInPageObj;
		
	}
	
	public CreateDemandPage getCreateDemandPageObj() {
		
		createDemandPageObj = new CreateDemandPage(driver);
		return createDemandPageObj;
		
	}

}
