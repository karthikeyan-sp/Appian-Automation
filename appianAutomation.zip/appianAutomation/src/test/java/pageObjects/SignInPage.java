package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SignInPage {
	
	public WebDriver driver;
	public SignInPage(WebDriver driver) {
		this.driver = driver;
		
	}
	//String userName, String pwd
	By userName = By.xpath("//input[@id='un']");
	By pwd = By.xpath("//input[@id='pw']");
	By signIn = By.xpath("//body/div[@id='loginBox']/div[1]/form[2]/div[4]/div[1]/div[2]/input[1]");
	By menuCustomerManagement = By.xpath("//div[@class=\"SiteMenuTab---nav_label\"][contains(text(), 'Customer Management')]");
	By linkCustomerManangement = By.xpath("//strong[@class='StrongText---richtext_strong']");
	By creatDemand = By.xpath("//button[contains(text(),'Create Demand')]");
	
	public void singIn() {
		
		driver.findElement(userName).sendKeys("a177446");
		driver.findElement(pwd).sendKeys("Kikasa!989");
		driver.findElement(signIn).click();
				
	}
	
	public void customerManagement() throws InterruptedException{
		
		Thread.sleep(1000);
		driver.findElement(menuCustomerManagement).click();
		driver.findElement(linkCustomerManangement).click();
		//driver.findElement(creatDemand).click();
		Thread.sleep(3000);
		
	}
	
	public void clickObject() {
		
	}

}
