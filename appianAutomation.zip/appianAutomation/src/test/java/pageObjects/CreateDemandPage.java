package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CreateDemandPage {
	
	public WebDriver driver;
	public CreateDemandPage(WebDriver driver) {
		this.driver = driver;
		
	}
	
		By creatDemand = By.xpath("//button[contains(text(),'Create Demand')]");
		By policyNumber = By.xpath("//input[@id='7d5e2fa6587c958213a94774277ec7dc']");
		By groupNumber = By.xpath("//input[@id='15395e5153c2e87b6669890ce5c33cb9']");
		By caseReference = By.xpath("//input[@id='00ada2ddecb6bbcdac45a4b3170bb072']");
		By demandFilter = By.xpath("//div[@id='2324f71402db4919891352ce26c8466d_value']");
		By demandType = By.xpath("//div[@id='a6ad9408ebefbfa13216144512f6956f_value']");
		By customerAgreedDate = By.xpath("//input[@id='8cd3ed8895b0221a56dc9f20ba4551db']");
		By notes = By.xpath("//textarea[@id='3639b6989bec39e1c8da076571e09b58']");
		By assignee = By.xpath("//div[@id='c4d274fc83b0abc2c4343339cc1bd69b_pickerContents']");
		By btnCreateDemand = By.xpath("//button[contains(text(),'Create demand')]");
		/*By policyNumber = By.xpath(null);
		By policyNumber = By.xpath(null);
		
	
		Policy number: TK91498027
		Demand Filter value: Error Management
		Demand value: Rewrite
		Customer agreed date: 
		02/02/2022 dd/mm/yyyy
		Assignee: 
		*/
		
		public void CreateDemand() throws InterruptedException {
			
			driver.findElement(creatDemand).click();
			driver.findElement(policyNumber).sendKeys("TK91498027");
			Thread.sleep(10000);
			driver.findElement(groupNumber).click();
			Thread.sleep(10000);
			
		}
}
