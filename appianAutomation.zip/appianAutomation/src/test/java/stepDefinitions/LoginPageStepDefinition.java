package stepDefinitions;


import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pageObjects.SignInPage;
import utils.DITestSetup;

public class LoginPageStepDefinition {
	DITestSetup diTestSetup;
	
	public LoginPageStepDefinition(DITestSetup diTestSetup) {
		
		this.diTestSetup = diTestSetup;
		
	}
	
	@Given("SignIn before creating demand")
	public void sign_in_before_creating_demand() throws InterruptedException {
		
		System.out.println("SignIn before creating demand");
		SignInPage signInPage = diTestSetup.pageObjectManagerObj.getSignInPageObj();
		
		//SignInPage signInPage = new SignInPage(diTestSetup.driver);
		signInPage.singIn();
		Thread.sleep(7000);
		signInPage.customerManagement();
		
	}
	@Then("SignOut after creating demand")
	public void sign_out_after_creating_demand() {
		System.out.println("SignOut after creating demand");
		}


}
