package stepDefinitions;

import java.io.IOException;

import io.cucumber.java.After;
import utils.DITestSetup;
//import utils.DriversUtil;

public class Hooks {
	DITestSetup dITestSetupObj;
	
	public Hooks(DITestSetup dITestSetupObj) {
		
		this.dITestSetupObj = dITestSetupObj;
		
	}
	
	@After
	public void AfterScenario() throws IOException {
		
		dITestSetupObj.driversUtilObj.WebDriverManager().quit();
	}

}
