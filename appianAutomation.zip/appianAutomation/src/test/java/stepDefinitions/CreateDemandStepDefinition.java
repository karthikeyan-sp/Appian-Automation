package stepDefinitions;


import org.openqa.selenium.WebDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.CreateDemandPage;
import utils.DITestSetup;

public class CreateDemandStepDefinition {
	public WebDriver driver;
	DITestSetup diTestSetup;
	
	public CreateDemandStepDefinition(DITestSetup diTestSetup) {
		
		this.diTestSetup = diTestSetup;
		
	}
	
	@Given("Create Demand for policy number in Customer Management page")
	public void create_demand_for_policy_number_in_customer_management_page() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new io.cucumber.java.PendingException();
		//Thread.sleep(5000);
		//CreateDemandPage createDemandPageObj = diTestSetup.pageObjectManagerObj.getCreateDemandPageObj();
		//createDemandPageObj.CreateDemand();
		//Thread.sleep(5000);
	}
	
	/*
	public void create_demand_for(String policyNumberVal) throws InterruptedException {
		System.out.println("Given -> Create a demand");
		CreateDemandPage createDemandPage = diTestSetup.pageObjectManagerObj.getCreateDemandPageObj();
		createDemandPage.CreateDemand();
		//("TK91498027");
		//createDemandPage.CreateDemand(policyNumberVal);
		//createDemandPage.CreateDemand(policyNumberVal);
		
		
	} */
	@When("Before start the demand")
	public void before_start_the_demand() {
		System.out.println("When -> Before start the demand");
		
	}
	@Then("Start the demand")
	public void start_the_demand() {
		System.out.println("Then -> Start the demand");
	    
	}


}
