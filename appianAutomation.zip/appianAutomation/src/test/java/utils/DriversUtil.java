package utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class DriversUtil {
	
	public WebDriver driver;
	
	public WebDriver WebDriverManager() throws IOException {
		
		FileInputStream fisObj = new FileInputStream(System.getProperty("user.dir") + "/src/test/resources/global.properties");
		Properties property = new Properties();
		property.load(fisObj);
		String url = property.getProperty("runwayURL");
		if (driver == null){
			
			if(property.getProperty("browser").equalsIgnoreCase("chrome")){
				
				System.setProperty("webdriver.chrome.driver", "driver/chromedriver4");
				driver= new ChromeDriver();
			}
			if(property.getProperty("browser") == "firefox") {
				
				//System.setProperty("webdriver.chrome.driver", "driver/chromedriver4");
				//driver= new ChromeDriver();
			}
			
			driver.get(url);
			driver.manage().window().maximize();
		}
		return driver;		
		
	}

}
