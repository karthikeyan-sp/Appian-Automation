package utils;

import java.io.IOException;

import org.openqa.selenium.WebDriver;

import pageObjects.PageObjectManager;

public class DITestSetup {
		
		public WebDriver driver;
		public boolean status;
		public boolean eleEnabled;
		public PageObjectManager pageObjectManagerObj;
		public DriversUtil driversUtilObj;
		
		public DITestSetup() throws IOException {
			
			driversUtilObj = new DriversUtil();
			pageObjectManagerObj = new PageObjectManager(driversUtilObj.WebDriverManager());
			
			
		}
		
		


}
